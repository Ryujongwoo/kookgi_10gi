import java.util.Random;

public class DiceTest2 {

	public static void main(String[] args) {
		
		Random random = new Random();
//		int num1 = 0, num2 = 0, num3 = 0, num4 = 0, num5 = 0, num6 = 0;
		int[] count = new int[6];
		
		for (int i = 0; i < 10; i++) {
			int r = random.nextInt(6) + 1;
			System.out.println(r);
			
//			switch (r) {
//				case 1:
//					count[0]++; break;
//				case 2:
//					count[1]++; break;
//				case 3:
//					count[2]++; break;
//				case 4:
//					count[3]++; break;
//				case 5:
//					count[4]++; break;
//				case 6:
//					count[5]++; break;
//			}
			
			count[r - 1]++;
			
		}
		
//		System.out.println("1�� ���� : " + count[0]);
//		System.out.println("2�� ���� : " + count[1]);
//		System.out.println("3�� ���� : " + count[2]);
//		System.out.println("4�� ���� : " + count[3]);
//		System.out.println("5�� ���� : " + count[4]);
//		System.out.println("6�� ���� : " + count[5]);
		
		for (int i = 0; i < count.length; i++) {
			System.out.println(i + 1 + "�� ���� : " + count[i]);
		}
		
	}
	
}













