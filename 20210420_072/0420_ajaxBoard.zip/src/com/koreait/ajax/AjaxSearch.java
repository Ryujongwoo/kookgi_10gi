package com.koreait.ajax;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AjaxSearch")
public class AjaxSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AjaxSearch 서블릿이 get 방식으로 요청됨");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AjaxSearch 서블릿이 post 방식으로 요청됨");
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AjaxSearch 서블릿의 actionDo() 메소득 실행됨");
		request.setCharacterEncoding("UTF-8");
//		처리한 데이터가 전송되는 컨텐츠 타입을 설정한다.
		response.setContentType("text/html; charset=UTF-8");
		String name = request.getParameter("name");
//		System.out.println(name);
		
//		ajax 방식으로 요청한 곳을 데이터를 리턴시킨다. => ajax로 서블릿을 호출한 쪽에서 responseTest를 사용해서 받ㄴ느다.
		response.getWriter().write("밥먹고 합시다.");
	}

}






