package com.koreait.layoutTest;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.Frame;
import java.awt.Label;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Random;

import javax.swing.JLabel;

//	CardLayout은 컨테이너에 카드를 여러장 엎어놓은 것 처럼 컴포넌트를 배치하는 레이아웃 매니저이다. JFrame에는 적용이 안된다.
public class CardLayoutTest2 extends Frame implements Runnable {
	
	JLabel[] jLabels = new JLabel[10];
	CardLayout card = new CardLayout();
	
	public CardLayoutTest2() {
		setTitle("CardLayout");
		setBounds(800, 100, 400, 600);
		
		setLayout(card);
		
		for (int i = 0; i < jLabels.length; i++) {
			jLabels[i] = new JLabel(9 - i + "");
			jLabels[i].setOpaque(true);
			jLabels[i].setBackground(Color.ORANGE);
			jLabels[i].setFont(new Font("Dialog", Font.BOLD, 400));
			jLabels[i].setHorizontalAlignment(JLabel.CENTER);
			add(9 - i + "", jLabels[i]);
		}
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		setVisible(true);
	}
	
	public static void main(String[] args) {
		
		CardLayoutTest2 window = new CardLayoutTest2();
		Thread thread = new Thread(window);
		thread.start();
		
	}

	@Override
	public void run() {
		
		Random random = new Random();
		while (true) {
			
			for (int i = 0; i < jLabels.length; i++) {
				try { Thread.sleep(100); } catch (InterruptedException e) { e.printStackTrace(); }
				
				int r = random.nextInt(256);
				int g = random.nextInt(256);
				int b = random.nextInt(256);
				jLabels[i].setBackground(new Color(r, g, b));
				jLabels[i].setForeground(new Color(random.nextInt(16777216)));
				
				card.show(this, 9 - i + "");
			}
			
		}
		
	}

}






