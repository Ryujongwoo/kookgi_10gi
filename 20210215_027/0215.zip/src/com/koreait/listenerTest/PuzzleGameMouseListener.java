package com.koreait.listenerTest;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Random;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class PuzzleGameMouseListener extends JFrame implements ActionListener, MouseListener {
	
	JPanel puzzlePanel = new JPanel(new GridLayout(4, 4));
	JButton[] puzzleButton = new JButton[16];
	String[] numbers = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16"};
	JButton startButton = new JButton("시작");
	Random random = new Random();
	
	public PuzzleGameMouseListener() {
		setTitle("ActionListener");
		setBounds(1200, 100, 400, 500);
		
		viewPuzzle();
		startButton.setFont(new Font("궁서체", Font.BOLD, 50));
		startButton.setPreferredSize(new Dimension(400, 100));
		startButton.addActionListener(this);
		startButton.addMouseListener(this);
		add(startButton, BorderLayout.SOUTH);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setVisible(true);
	}

	private void viewPuzzle() {
		for (int i = 0; i < puzzleButton.length; i++) {
			puzzleButton[i] = new JButton(numbers[i]);
			puzzleButton[i].setFont(new Font("Dialog", Font.BOLD, 40));
//			puzzleButton[i].addActionListener(this);
			puzzleButton[i].addMouseListener(this);
			puzzleButton[i].setName(numbers[i]);
			puzzlePanel.add(puzzleButton[i]);
			if (puzzleButton[i].getActionCommand().equals("16")) {
				puzzleButton[i].setVisible(false);
			}
		}
		add(puzzlePanel, BorderLayout.CENTER);
	}
	
	public static void main(String[] args) {
		
		PuzzleGameMouseListener window = new PuzzleGameMouseListener();
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
//		if (e.getActionCommand().equals("시작")) {
			for (int i = 0; i < 1000000; i++) {
				int r = random.nextInt(15) + 1;
				String temp = numbers[0];
				numbers[0] = numbers[r];
				numbers[r] = temp;
			}
			reView();
//		}
		
	}

	private void reView() {
		for (int i = 0; i < puzzleButton.length; i++) {
			puzzleButton[i].setVisible(true);
			puzzlePanel.remove(puzzleButton[i]);
		}
		viewPuzzle();
		revalidate();
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		
//		System.out.println(e);
		Object object = e.getSource();
		JButton button = (JButton) object;
//		System.out.println(button.getName());
		
		if (!button.getActionCommand().equals("시작")) {
		int i;
		for (i = 0; i < puzzleButton.length; i++) {
			if (puzzleButton[i].getActionCommand().equals(button.getActionCommand())) {
				break;
			}
		}
//		System.out.println(i + "번째 버튼에서 MouseListener가 실행됨");
		
		if (i % 4 != 0) {
			if (puzzleButton[i - 1].getActionCommand().equals("16")) {
				String temp = numbers[i - 1];
				numbers[i - 1] = numbers[i];
				numbers[i] = temp;
				JButton tempBth = puzzleButton[i - 1];
				puzzleButton[i - 1] = puzzleButton[i];
				puzzleButton[i] = tempBth;
			}
		}
		
		if (i % 4 != 3) {
			if (puzzleButton[i + 1].getActionCommand().equals("16")) {
				String temp = numbers[i + 1];
				numbers[i + 1] = numbers[i];
				numbers[i] = temp;
				JButton tempBth = puzzleButton[i + 1];
				puzzleButton[i + 1] = puzzleButton[i];
				puzzleButton[i] = tempBth;
			}
		}
		
		if (i / 4 != 0) {
			if (puzzleButton[i - 4].getActionCommand().equals("16")) {
				String temp = numbers[i - 4];
				numbers[i - 4] = numbers[i];
				numbers[i] = temp;
				JButton tempBth = puzzleButton[i - 4];
				puzzleButton[i - 4] = puzzleButton[i];
				puzzleButton[i] = tempBth;
			}
		}
		
		if (i / 4 != 3) {
			if (puzzleButton[i + 4].getActionCommand().equals("16")) {
				String temp = numbers[i + 4];
				numbers[i + 4] = numbers[i];
				numbers[i] = temp;
				JButton tempBth = puzzleButton[i + 4];
				puzzleButton[i + 4] = puzzleButton[i];
				puzzleButton[i] = tempBth;
			}
			
		}
		
		reView();
		
		good:
		while (true) {
			for (i = 0; i < puzzleButton.length - 1; i++) {
				if (i + 1 != Integer.parseInt(puzzleButton[i].getActionCommand())) {
					break good;
				}
			}
			JOptionPane.showMessageDialog(puzzlePanel, "맞췄다~~~~~ 축하해~~~~~");
			break;
		}
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		
		Object object = e.getSource();
		JButton button = (JButton) object;

		if (button.getActionCommand().equals("시작")) {
			System.out.println("mouseClicked()");
		}
		
	}
	
	
	@Override
	public void mouseExited(MouseEvent e) { }
	@Override
	public void mousePressed(MouseEvent e) { }
	@Override
	public void mouseReleased(MouseEvent e) { }

}












 





