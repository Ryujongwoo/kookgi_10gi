package com.koreait.service;

import com.koreait.vo.MvcboardVO;

public interface MvcboardService {

	void execute(MvcboardVO mvcboardVO);
	
}
