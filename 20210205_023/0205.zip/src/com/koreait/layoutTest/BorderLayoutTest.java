package com.koreait.layoutTest;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JLabel;

public class BorderLayoutTest extends Frame {
	
	JLabel label = new JLabel("TEXT1");
	JLabel label2 = new JLabel("TEXT2");
	JLabel label3 = new JLabel("TEXT3");
	JLabel label4 = new JLabel("TEXT4");
	JLabel label5 = new JLabel("<html>한줄<br/>두우주울</html>");
	
	public BorderLayoutTest() {
		setTitle("BorderLayout");
		setBounds(800, 100, 400, 600);
		
//		BorderLayout을 만들고 적용시킨다. => BorderLayout은 Frame, JFrame의 기본 레이아웃이므로 적용하지 않아도 된다.
		BorderLayout border = new BorderLayout();
		setLayout(border);
		
		label.setOpaque(true);
		label.setBackground(Color.YELLOW);
		label.setHorizontalAlignment(JLabel.CENTER);
		label.setPreferredSize(new Dimension(400, 50));
//		add(컴포넌트, 방향), 방향을 생략하면 CENTER가 기본값으로 사용된다.
		add(label, BorderLayout.NORTH);
		
		label2.setOpaque(true);
		label2.setBackground(Color.PINK);
		label2.setHorizontalAlignment(JLabel.CENTER);
		label2.setPreferredSize(new Dimension(400, 50));
		add(label2, BorderLayout.SOUTH);
		
		label3.setOpaque(true);
		label3.setBackground(Color.GREEN);
		label3.setHorizontalAlignment(JLabel.CENTER);
		label3.setPreferredSize(new Dimension(50, 600));
		add(label3, BorderLayout.EAST);
		
		label4.setOpaque(true);
		label4.setBackground(Color.ORANGE);
		label4.setHorizontalAlignment(JLabel.CENTER);
		label4.setPreferredSize(new Dimension(50, 600));
//		add(label4, BorderLayout.WEST);
//		add("방향", 컴포넌트) : 방향은 반드시 큰따옴표 안에 첫 문자만 대문자로 지정해야 한다.
		add("West", label4);
		
		label5.setOpaque(true);
		label5.setBackground(Color.MAGENTA);
		label5.setHorizontalAlignment(JLabel.CENTER);
//		add(label5, BorderLayout.CENTER);
		add(label5);		// 방향을 생략했으므로 기본값인 CENTER에 배치된다.
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		setVisible(true);
	}
	
	public static void main(String[] args) {
		
		BorderLayoutTest window = new BorderLayoutTest();
		
	}

}
