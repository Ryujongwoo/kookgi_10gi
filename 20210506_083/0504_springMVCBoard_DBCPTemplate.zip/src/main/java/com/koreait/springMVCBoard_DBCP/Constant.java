package com.koreait.springMVCBoard_DBCP;

import org.springframework.jdbc.core.JdbcTemplate;

public class Constant {

//	다른 클래스에서 접근해서 사용을 해야되기 때문에 public으로 선언한다.
	public static JdbcTemplate template;
	
}
