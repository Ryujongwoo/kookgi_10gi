package com.koreait.dao;

import org.apache.ibatis.session.SqlSession;

import com.koreait.vo.FreeboardCommentVO;

public class FreeboardCommentDAO {

	private static FreeboardCommentDAO instance = new FreeboardCommentDAO();
	private FreeboardCommentDAO() { }
	public static FreeboardCommentDAO getInstance() { return instance; }
	
//	FreeboardCommentService 클래스에서 mapper와 댓글 데이터가 저장된 객체를 넘겨받고 freeboardcomment.xml 파일의 
//	insert sql 명령을 실행하는 메소드
	public void insertComment(SqlSession mapper, FreeboardCommentVO vo) {
		System.out.println("FreeboardCommentDAO 클래스의 insertComment() 메소드");
		mapper.insert("insertComment", vo);
	}

}
