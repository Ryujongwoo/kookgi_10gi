package com.koreait.springMVCRequest;

import java.text.DateFormat;
import java.util.Date;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(Locale locale, Model model) {
		logger.info("Welcome home! The client locale is {}.", locale);
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateTimeInstance(DateFormat.LONG, DateFormat.LONG, locale);
		
		String formattedDate = dateFormat.format(date);
		
		model.addAttribute("serverTime", formattedDate );
		
		return "home";
	}

	@RequestMapping("/memberView")
	public String memberView(HttpServletRequest request, Model model) {
		System.out.println("HomeController의 memberView() 메소드");
		
//		뷰 페이지에서 컨트롤러로 넘어와 HttpServletRequest 인터페이스 객체에 저장되는 데이터를 받는다.
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		System.out.println("id: " + id + ", pw: " + pw);
		
//		컨트롤러에서 뷰 페이지로 넘겨줄 데이터를 Model 인터페이스 객체에 저장한다.
		model.addAttribute("id", id);
		model.addAttribute("pw", pw);
		
		return "memberView";
	}
	
	@RequestMapping("/memberLogin")
//	@RequestParam("뷰 페이지에서 컨트롤러로 넘어오는 변수명") 자료형 변수명
//	@RequestParam("id") String id => String id = request.getParameter("id")와 같은 기능이 실행된다.
//	HttpServletRequest 인터페이스 객체로 뷰 페이지에서 넘어오는 데이터를 받을 때는 데이터가 넘어오지 않아도 에러가 발생되지 않았지만
//	@RequestParam 어노테이션을 사용해서 뷰 페이지에서 넘어오는 데이터를 받을 때는 뷰 페이지에서 데이터가 넘어오지 않으면 400 에러가 발생된다.
	public String memberLogin(/*HttpServletRequest request,*/ Model model, @RequestParam("id") String id, @RequestParam("pw") String pw) {
		System.out.println("HomeController의 memberLogin() 메소드");
		System.out.println("id: " + id + ", pw: " + pw);
		model.addAttribute("id", id);
		model.addAttribute("pw", pw);
		return "memberLogin";
	}
	
	@RequestMapping("/member")
	public String member(HttpServletRequest request, Model model) {
		System.out.println("HomeController의 member() 메소드");
		return "member";
	}
	
}






















