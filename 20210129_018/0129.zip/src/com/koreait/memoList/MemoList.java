package com.koreait.memoList;

import java.util.ArrayList;

public class MemoList {

	private ArrayList<MemoVO> memoList = new ArrayList<MemoVO>();

	public ArrayList<MemoVO> getMemoList() {
		return memoList;
	}
	public void setMemoList(ArrayList<MemoVO> memoList) {
		this.memoList = memoList;
	}
	
	@Override
	public String toString() {
//		마지막에 입력한 글(최신글) 부터 출력하기 위해서 ArrayList에 저장된 마지막 글 부터 출력한다.
		String str = "";
		if (memoList.size() == 0) {
			str += "저장된 메모가 없습니다.";
		} else {
			for (int i = memoList.size() - 1; i >= 0; i--) {
				str += memoList.get(i) + "\n";
			}
		}
		return str;
	}
	
//	MemoProject 클래스에서 호출되는 memoList라는 ArrayList에 저장할 데이터가 저장된 MemoVO 클래스의 객체를 넘겨받고 memoList라는 ArrayList에 
//	저장하는 메소드
	public void addMemo(MemoVO vo) {
		memoList.add(vo);
	}
	
//	MemoProject 클래스에서 호출되는 수정 또는 삭제할 글번호를 넘겨받고 memoList라는 ArrayList에 저장글 중에서 글번호에 해당되는 글 1건 리턴하는
//	메소드
	public MemoVO selectMemo(int idx) {
		try {
			return memoList.get(idx - 1);
		} catch (IndexOutOfBoundsException e) {
			return null;
		}
	}
	
//	MemoProject 클래스에서 호출되는 삭제할 글번호를 넘겨받고 memoList라는 ArrayList에 저장글 중에서 글번호에 해당되는 글 1건 삭제하는 메소드
	public void delete(int idx) {
		memoList.remove(idx - 1);
	}
	
	
}









