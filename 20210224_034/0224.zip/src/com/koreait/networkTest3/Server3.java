package com.koreait.networkTest3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class Server3 extends JFrame implements ActionListener, Runnable {

	JTextArea textArea;			// 대화 내용이 출력될 영역
	JPanel panel;				// 대화 내용을 입력하는 텍스트 필드와 전송 버튼이 올라갈 패널
	JTextField textField;		// 대화 내용을 입력하는 텍스트 필드
	JButton button;				// 텍스트 필드에 입력한 대화 내용을 전송하는 버튼
	
	public Server3() {
		setTitle("1:1 채팅 프로그램 - 서버");
		setBounds(100, 50, 500, 700);
		
//		채팅창 만들기
		textArea = new JTextArea();
		textArea.setBackground(Color.ORANGE);
		textArea.setEnabled(false);
		add(textArea, BorderLayout.CENTER);
		
		panel = new JPanel(new BorderLayout());
		panel.setPreferredSize(new Dimension(500, 40));
		textField = new JTextField();
		panel.add(textField, BorderLayout.CENTER);
		button = new JButton("전송");
		panel.add(button, BorderLayout.EAST);
		add(panel, BorderLayout.SOUTH);
		
//		텍스트 필드와 전송 버튼에 ActionListener를 걸어준다.
		textField.addActionListener(this);
		button.addActionListener(this);
		
		addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		setVisible(true);
	}
	
	public static void main(String[] args) {
		Server3 server = new Server3();
	}

//	텍스트 필드 또는 전송 버튼에서 ActionListener가 실행되면 클라이언트로 데이터를 전송한다.
	@Override
	public void actionPerformed(ActionEvent e) {
		
		System.out.println("꺄~~~~~~~~~~~~~~~~");
		
	}

//	클라이언트에서 언제 메시지를 보내올지 모르기 때문에 통신이 종료될 때 까지 반복하며 클라이언트에서 전송되는 메시를 받는다.
	@Override
	public void run() {
		
		
		
	}
	
}












