package com.koreait.springAOP2_java;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

//	java 파일을 이용해서 AOP 설정을 하려면 AOP를 설정할 클래스에 @Aspect 어노테이션을 붙여준다.
@Aspect
public class LogAOP {

//	pointcut을 지정하는 첫 번째 방법 => 빈 메소드를 이용해서 pointcut을 만든다.
//	적당한 이름을 빈 메소드를 만든 후 @Pointcut 어노테이션을 붙여서 인수에 pointcut을 지정한다.
//	AOP 어노테이션 => @Before, @AfterReturning, @AfterThrowing, @After, @Around
//	pointcut 메소드를 만든 후 AOP 메소드에 pointcut을 지정하려면 AOP 어노테이션의 인수로 pointcut 메소드를 적어준다.
	@Pointcut("within(com.koreait.springAOP2_java.Student)")
	public void pointcutMethod() {
//		빈 메소드 => pointcut 1개를 만들어서 여러 AOP 메소드에 pointcut을 지정할 때 사용한다.
	}
	
	@Before("pointcutMethod()")
	public void before() {
		System.out.println("LogAOP 클래스의 before() 메소드가 실행됨");
	}

	@AfterReturning("pointcutMethod()")
	public void afterReturning() {
		System.out.println("LogAOP 클래스의 afterReturning() 메소드가 실행됨");
	}
	
	@AfterThrowing("pointcutMethod()")
	public void afterThrowing() {
		System.out.println("LogAOP 클래스의 afterThrowing() 메소드가 실행됨");
	}
	
	@After("pointcutMethod()")
	public void after() {
		System.out.println("LogAOP 클래스의 after() 메소드가 실행됨");
	}
	
//	pointcut을 지정하는 두 번째 방법 => AOP 어노테이션의 인수에 pointcut을 바로 지정할 수 있다.
	@Around("execution(* com.koreait.springAOP2_java.W*.*())")
	public Object around(ProceedingJoinPoint joinPoint) throws Throwable {
		System.out.println("LogAOP 클래스의 around() 메소드가 실행됨 - 핵심 기능 실행 전");
		long startTime = System.currentTimeMillis();
		try {
			System.out.println("LogAOP 클래스의 around() 메소드가 실행됨 - 핵심 기능 실행 중");
			Object object = joinPoint.proceed();
			return object;
		} finally {
			long endTime = System.currentTimeMillis();
			System.out.println("LogAOP 클래스의 around() 메소드가 실행됨 - 핵심 기능 실행 후");
			System.out.println("핵심 기능이 실행되는데 걸린 시간 : " + (endTime - startTime) / 1000. + "초");
		}
		
	}
	
}

























