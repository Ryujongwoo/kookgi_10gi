package com.koreait.ajax;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/AjaxInsert")
public class AjaxInsert extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AjaxInsert 서블릿이 get 방식으로 요청됨");
		actionDo(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AjaxInsert 서블릿이 post 방식으로 요청됨");
		actionDo(request, response);
	}
	
	protected void actionDo(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("AjaxInsert 서블릿의 actionDo() 메소드 실행됨");
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html; charset=UTF-8");
		
//		입력 양식에서 넘어오는 데이터를 받는다.
		String name = request.getParameter("name");
		int age = Integer.parseInt(request.getParameter("age"));
		String gender = request.getParameter("gender");
		String email = request.getParameter("email");
		
//		넘겨받은 데이터를 테이블에 저장하고 처리 결과(숫자)를 리턴시킨다.
//		write() 메소드는 인수로 문자열만 가질 수 있으므로 공백을 붙여서 문자열로 만들어 리턴시킨다.
		response.getWriter().write(insert(name, age, gender, email) + "");
	}

	private int insert(String name, int age, String gender, String email) {
		AjaxVO vo = new AjaxVO();
		vo.setName(name);
		vo.setAge(age);
		vo.setGender(gender);
		vo.setEmail(email);
		return new AjaxDAO().insert(vo);
	}
	
}






















