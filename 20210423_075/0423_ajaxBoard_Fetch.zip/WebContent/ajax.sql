CREATE TABLE "AJAX" (
    "IDX" NUMBER(*,0) NOT NULL, 
	"NAME" VARCHAR2(20 BYTE) NOT NULL, 
	"AGE" NUMBER(*,0) NOT NULL, 
	"GENDER" VARCHAR2(20 BYTE) NOT NULL, 
	"EMAIL" VARCHAR2(50 BYTE) NOT NULL, 
	PRIMARY KEY ("IDX")
);

delete from ajax;
drop sequence ajax_idx_seq;
create sequence ajax_idx_seq;
commit;

insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, 'ȫ�浿', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '�Ӳ���', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '����', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '������', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '�տ���', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '���Ȱ�', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '�����', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '��縶', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '������', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '��õ����', '20', '��', 'a@a.com');
insert into ajax (idx, name, age, gender, email) values (ajax_idx_seq.nextval, '���κο�', '20', '��', 'a@a.com');

select count(*) from ajax;
