package com.koreait.bookshop;

import java.util.Date;

public class BookShop {

	public static void main(String[] args) {
		
		/*
//		VO 클래스 테스트
		BookVO book1 = new BookVO();
		System.out.println(book1.toString());
//		클래스로 생성한 객체를 출력할 때 객체 이름 뒤에 toString() 메소드를 붙이지 않아도 자바가 알아서 붙여준다.
		System.out.println(book1);
//		System.out.println(book1.title);	// private 권한을 가지는 멤버 변수에 접근할 수 없으므로 에러가 발생된다.

		BookVO book2 = new BookVO("JAVA", "홍길동", "코리아출판사", new Date(2015, 5, 12), 35000);
		System.out.println("book2 : " + book2);
		
		BookVO book3 = new BookVO("JAVA", "홍길동", "코리아출판사", new Date(2015, 5, 12), 35000);
		System.out.println("book3 : " + book3);
		
//		"=="을 사용해서 같은가 비교할 수 있는 데이터는 기본 자료형 8가지와 null만 가능하다. => 클래스 객체는 비교할 수 없다.
//		String은 단일 데이터가 저장된 클래스라서 equals() 메소드만 사용하면 저장된 내용이 같은가 다른가 비교할 수 있지만 String을 제외한 나머지
//		클래스 객체는 equals() 메소드만 사용하면 hashcode - 객체를 식별하기 위해 자바가 붙이는 의미없는 32비트의 숫자 - 를 비교하기 때문에
//		저장된 데이터가 같으면 같은 객체로 인식하게 하기 위해서 hashcode를 같게 만들어주고 실제 저장된 데이터를 비교해야 한다.
		if (book2.equals(book3)) {
			System.out.println("같다");
		} else {
			System.out.println("다르다");
		}
		
		System.out.println(book2.getAuthor());
		book2.setAuthor("임꺽정");
		System.out.println(book2);
		*/
		
	}
	
}





