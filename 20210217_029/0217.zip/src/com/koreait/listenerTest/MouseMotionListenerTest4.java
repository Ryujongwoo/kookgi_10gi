package com.koreait.listenerTest;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.Random;

import javax.swing.JOptionPane;
import javax.swing.JPanel;

public class MouseMotionListenerTest4 extends JPanel implements Runnable {

	int xpos = 50, ypos = 50;
	static int xbar = 175;
	
	public static void main(String[] args) {
		
		Frame window = new Frame("GraphicTest");
		window.setBounds(1200, 100, 500, 600);
		
		MouseMotionListenerTest4 graphic = new MouseMotionListenerTest4();
		window.add(graphic);

		graphic.addMouseMotionListener(new MouseAdapter() {

			@Override
			public void mouseMoved(MouseEvent e) {
				
				xbar = e.getX() - 75;
				xbar = xbar < 0 ? 0 : xbar;
				xbar = xbar > 335 ? 335 : xbar;
				
			}
			
		});
		
		Thread thread = new Thread(graphic);
		thread.start();
		
		window.addWindowListener(new WindowAdapter() {
			@Override
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
		window.setVisible(true);
		
	}

	@Override
	public void paint(Graphics g) {
		
		g.setColor(Color.WHITE);
		g.fillRect(0, 0, 500, 600);
		g.setColor(Color.RED);
		g.fillOval(xpos, ypos, 50, 50);
		
//		수평 막대를 만든다.
		g.setColor(Color.GREEN);
		g.fillRect(xbar, 520, 150, 25);
		
	}

	@Override
	public void run() {
		
		int xsw = 1, ysw = 1;
		while (true) {
			
			xpos += xsw;
			if (xpos > 435 || xpos < 0) {
				xsw *= -1;
			}
			ypos += ysw;
			if ((ypos > 470 && xpos >= xbar && xpos <= xbar + 150) || ypos < 0) {
				ysw *= -1;
			}
			if (ypos >= 500) {
				break;
			}
			try { Thread.sleep(5); } catch (InterruptedException e) { e.printStackTrace(); }
			repaint();
			
		}
		
		JOptionPane.showMessageDialog(null, "Game Over!!!");
		System.exit(0);
		
	}

}












 